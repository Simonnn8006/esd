    <!-- Optionnel : Barre bleue en bas -->
    <div class="social-bar">
        <p>&copy; 2024 ESDOWN - Tous droits réservés</p>
        <!-- App made with love by K_lfa & Heazzy -->
    </div>

</body>
<script src="/js/functions.js"></script>
</html>
