<?php
$servername = "db";
$username = "example_user";
$password = "example_password";
$dbname = "Website";
$posts_per_page = 6;

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
