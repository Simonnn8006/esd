<?php

session_start();

// Si l'utilisateur n'est pas connecté, redirection vers login.php
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

include 'config.php';
include 'header.php'; 

function makeRequestToLocalhost() {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://localhost:9070/debug.php");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}


// Variables pour stocker les résultats
$ssrfResult = "";

// Traitement du formulaire pour la SSRF
if (isset($_GET['procedure_url'])) {
    $procedureUrl = $_GET['procedure_url'];
    makeRequestToLocalhost();
    $procedureContent = file_get_contents($procedureUrl);

    if ($procedureContent !== false) {
        $ssrfResult .= "<div class='container text-center mt-5'>";
        $ssrfResult .= "<h3>Procédure récupérée depuis le site partenaire :</h3>";
        $ssrfResult .= "<div class='procedure-content'>";
        $ssrfResult .= nl2br($procedureContent);
        $ssrfResult .= "</div></div>";
    } else {
        $ssrfResult .= "<p class='text-danger'>Erreur lors de la récupération de la procédure.</p>";
    }
}

?>

<div class="container text-center mt-5">
    <h1 class="welcome-message">Bienvenue sur l'intranet ESDOWN</h1>
    <p class="description">Vous pouvez consulter les procédures et documents internes ou gérer votre compte.</p>

    <!-- Formulaire pour inclure des procédures depuis un site partenaire (SSRF) -->
    <form method="GET" action="">
        <div class="form-group">
            <label for="procedure_url">URL de la procédure (site partenaire) :</label>
            <input type="text" class="form-control" id="procedure_url" name="procedure_url" placeholder="Entrez l'URL">
        </div>
        <button type="submit" class="btn btn-primary mt-2">Charger la procédure</button>
    </form>

    <!-- Affichage des résultats SSRF -->
    <?= $ssrfResult ?>
</div>

<?php
include 'footer.php';
?>
