<?php

session_start();

// Chemin vers les logs Apache
$logFile = '/var/log/apache2/access.log'; // Tu peux aussi accéder à error.log si nécessaire

// Nombre de lignes à afficher
$linesToDisplay = 50;

// Vérifier si le fichier existe
if (file_exists($logFile)) {
    // Lire tout le fichier de log
    $logContent = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    if ($logContent !== false) {
        // Récupérer les 50 dernières lignes
        $lastLines = array_slice($logContent, -$linesToDisplay);

        // Sauvegarder temporairement les dernières lignes dans un fichier temporaire
        $tempFile = '/tmp/last_lines_log';
        file_put_contents($tempFile, implode("\n", $lastLines));

        // Inclure le fichier temporaire avec les dernières lignes
        include($tempFile);

        // Supprimer le fichier temporaire pour éviter qu'il reste sur le serveur
        unlink($tempFile);
    } else {
        echo "<p>Impossible de lire le fichier de log.</p>";
    }
} else {
    echo "<p>Le fichier de log n'existe pas.</p>";
}

?>
